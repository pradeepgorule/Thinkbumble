import React from 'react';
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
function Sidebar() {
    return (
        <div>
            <span onClick={openNav} style={{fontSize:"25px",margin:"15px",cursor:"pointer"}}>&#9776;</span>
            <div id="mySidenav" class="sidenav">
                <a  className="closebtn" onClick={closeNav}>&times;</a>
                <a href="#">Menu 1</a>
                <a href="#">Menu 2</a>
                <a href="#">Menu 3</a>
                <a href="#">Menu 4</a>
            </div>
        </div>
    )
}

export default Sidebar;