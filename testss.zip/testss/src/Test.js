import React, { Component } from 'react';
import Sidebar from './Sidebar'


function Test() {

    return (
        <div>
            <Sidebar/>
            <div className="container">
                <div className="row">
                    <div className="col-md-2 bx-shadow">box1</div>
                    <div className="col-md-2 bx-shadow">box2</div>
                    <div className="col-md-6 bx-shadow">box3</div>
                </div>
                <div className="row">
                    <div className="col-md-4 bx-shadow">box1</div>
                    <div className="col-md-6">
                    <p className="row">
                        <div className="col-md-12 bx-shadow">box1</div>
                        </p>
                        <p className="row">

                        <div className="col-md-5 bx-shadow">box1</div>
                        <div className="col-md-5 bx-shadow">box2</div>
                        </p>
                    </div>

                </div>

            </div>

        </div>
    )


}
export default Test;